<?php
/**
 * Single resource template - display custom fields below featured image.
 *
 * @package Education_Resources_Manager
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class ERM_Single_Template
 */
class ERM_Single_Template {

	/**
	 * Initialize.
	 */
	public function init() {
		add_filter( 'the_content', array( $this, 'add_resource_meta' ), 10, 1 );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_styles' ) );
	}

	/**
	 * Enqueue styles for single resource page.
	 */
	public function enqueue_styles() {
		if ( ! is_singular( ERM_Post_Type::POST_TYPE ) ) {
			return;
		}

		wp_enqueue_style(
			'erm-public',
			ERM_URL . 'public/css/public-styles.css',
			array(),
			ERM_VERSION
		);
	}

	/**
	 * Add resource meta box to content.
	 *
	 * @param string $content Post content.
	 * @return string
	 */
	public function add_resource_meta( $content ) {
		if ( ! is_singular( ERM_Post_Type::POST_TYPE ) || ! in_the_loop() || ! is_main_query() ) {
			return $content;
		}

		$post_id = get_the_ID();
		$meta    = ERM_Post_Type::get_resource_meta( $post_id );

		$type_labels = array(
			'course'   => __( 'Curso', 'education-resources-manager' ),
			'tutorial' => __( 'Tutorial', 'education-resources-manager' ),
			'ebook'    => __( 'Ebook', 'education-resources-manager' ),
			'video'    => __( 'Video', 'education-resources-manager' ),
		);

		$level_labels = array(
			'beginner'     => __( 'Principiante', 'education-resources-manager' ),
			'intermediate' => __( 'Intermedio', 'education-resources-manager' ),
			'advanced'     => __( 'Avanzado', 'education-resources-manager' ),
		);

		$items = array();

		if ( ! empty( $meta['type'] ) ) {
			$items[] = '<span class="erm-meta-badge erm-meta-type">' . esc_html( $type_labels[ $meta['type'] ] ?? $meta['type'] ) . '</span>';
		}

		if ( ! empty( $meta['level'] ) ) {
			$items[] = '<span class="erm-meta-badge erm-meta-level">' . esc_html( $level_labels[ $meta['level'] ] ?? $meta['level'] ) . '</span>';
		}

		if ( ! empty( $meta['duration'] ) && $meta['duration'] > 0 ) {
			$items[] = '<span class="erm-meta-duration">' . esc_html( sprintf( __( '%d min', 'education-resources-manager' ), $meta['duration'] ) ) . '</span>';
		}

		if ( ! empty( $meta['instructor'] ) ) {
			$items[] = '<span class="erm-meta-instructor">' . esc_html__( 'Por:', 'education-resources-manager' ) . ' ' . esc_html( $meta['instructor'] ) . '</span>';
		}

		if ( ! empty( $meta['price'] ) ) {
			$price_display = ( strtolower( $meta['price'] ) === 'gratuito' || $meta['price'] === '0' ) ? __( 'Gratuito', 'education-resources-manager' ) : esc_html( $meta['price'] );
			$items[] = '<span class="erm-meta-price">' . $price_display . '</span>';
		}

		$meta_html = '';
		if ( ! empty( $items ) ) {
			$meta_html = '<div class="erm-single-meta">' . implode( ' <span class="erm-meta-sep">•</span> ', $items ) . '</div>';
		}

		$button_html = '';
		if ( ! empty( $meta['url'] ) ) {
			$button_html = '<div class="erm-single-actions"><a href="' . esc_url( $meta['url'] ) . '" class="erm-btn erm-btn-primary" target="_blank" rel="noopener">' . esc_html__( 'Ver recurso', 'education-resources-manager' ) . '</a></div>';
		}

		$output = '';
		if ( $meta_html || $button_html ) {
			$output = '<div class="erm-single-meta-box">' . $meta_html . $button_html . '</div>';
		}

		return $output . $content;
	}
}
