/**
 * Block editor customization for erm_resource: replace default status panel
 * with a simplified panel showing only draft, published, archived.
 * Sincroniza bidireccionalmente con el meta box "Detalles del Recurso".
 *
 * @package Education_Resources_Manager
 */
( function () {
	'use strict';

	var META_TO_POST = { draft: 'draft', published: 'publish', archived: 'archived' };
	var POST_TO_META = { draft: 'draft', publish: 'published', archived: 'archived' };

	function getPostType() {
		var post = wp.data.select( 'core/editor' ).getCurrentPost();
		return post ? post.type : '';
	}

	function getPostId() {
		var post = wp.data.select( 'core/editor' ).getCurrentPost();
		return post ? post.id : 0;
	}

	function getCurrentStatus() {
		var post = wp.data.select( 'core/editor' ).getCurrentPost();
		if ( ! post ) return 'publish';
		var s = post.status || 'publish';
		if ( s === 'draft' || s === 'publish' || s === 'archived' ) return s;
		return 'publish';
	}

	function syncMetaBoxFromPostStatus( postStatus ) {
		var metaValue = POST_TO_META[ postStatus ] || 'published';
		var select = document.getElementById( 'erm_status' );
		if ( select && select.value !== metaValue ) {
			select.value = metaValue;
		}
	}

	function syncEditorFromMetaBox( metaValue ) {
		var postStatus = META_TO_POST[ metaValue ] || 'publish';
		var postId = getPostId();
		var postType = getPostType();
		if ( postId && postType ) {
			wp.data.dispatch( 'core' ).editEntityRecord( 'postType', postType, postId, { post_status: postStatus } );
		}
	}

	function ResourceStatusPanel() {
		var postType = getPostType();
		if ( postType !== 'erm_resource' ) {
			return null;
		}

		var status = getCurrentStatus();
		var postId = getPostId();
		var postTypeSlug = getPostType();

		var __ = ( wp.i18n && wp.i18n.__ ) ? wp.i18n.__ : function( s ) { return s; };
		var statusMap = [
			{ value: 'draft', label: __( 'Borrador', 'education-resources-manager' ), description: __( 'No listo para publicar.', 'education-resources-manager' ) },
			{ value: 'publish', label: __( 'Publicado', 'education-resources-manager' ), description: __( 'Visible por todos.', 'education-resources-manager' ) },
			{ value: 'archived', label: __( 'Archivado', 'education-resources-manager' ), description: __( 'Recurso archivado, no visible.', 'education-resources-manager' ) }
		];

		function onChange( newStatus ) {
			wp.data.dispatch( 'core' ).editEntityRecord( 'postType', postTypeSlug, postId, { post_status: newStatus } );
			syncMetaBoxFromPostStatus( newStatus );
		}

		return wp.element.createElement(
			wp.editor.PluginDocumentSettingPanel,
			{
				name: 'erm-resource-status',
				title: __( 'Estado y visibilidad', 'education-resources-manager' ),
				className: 'erm-resource-status-panel'
			},
			wp.element.createElement(
				'fieldset',
				{ className: 'components-radio-control' },
				wp.element.createElement(
					'legend',
					{ className: 'components-visually-hidden' },
					__( 'Estado', 'education-resources-manager' )
				),
				wp.element.createElement(
					'div',
					{ className: 'components-radio-control__group-wrapper' },
					statusMap.map( function ( opt ) {
						return wp.element.createElement(
							'div',
							{ key: opt.value, className: 'components-radio-control__option' },
							wp.element.createElement( 'input', {
								id: 'erm-status-' + opt.value,
								className: 'components-radio-control__input',
								type: 'radio',
								name: 'erm_resource_status',
								value: opt.value,
								checked: status === opt.value,
								onChange: function () { onChange( opt.value ); }
							} ),
							wp.element.createElement(
								'label',
								{ className: 'components-radio-control__label', htmlFor: 'erm-status-' + opt.value },
								opt.label
							),
							wp.element.createElement(
								'p',
								{ className: 'components-radio-control__option-description' },
								opt.description
							)
						);
					} )
				)
			)
		);
	}

	function ERMBlockEditorPlugin() {
		var postType = getPostType();
		if ( postType !== 'erm_resource' ) {
			return null;
		}

		// Remove default post-status panel for resources (password, scheduled, etc.).
		wp.element.useEffect( function () {
			var dispatch = wp.data.dispatch( 'core/edit-post' ) || wp.data.dispatch( 'core/editor' );
			if ( dispatch && typeof dispatch.removeEditorPanel === 'function' ) {
				dispatch.removeEditorPanel( 'post-status' );
			}
		}, [] );

		// Sincronizar meta box cuando cambia el estado en el editor.
		wp.element.useEffect( function () {
			var lastStatus = getCurrentStatus();
			syncMetaBoxFromPostStatus( lastStatus );
			var unsubscribe = wp.data.subscribe( function () {
				var status = getCurrentStatus();
				if ( status !== lastStatus ) {
					lastStatus = status;
					syncMetaBoxFromPostStatus( status );
				}
			} );
			return unsubscribe;
		}, [] );

		// Escuchar cambios en el meta box y actualizar el editor.
		wp.element.useEffect( function () {
			var teardown = null;
			function attachListener() {
				var select = document.getElementById( 'erm_status' );
				if ( ! select ) return false;
				function onMetaBoxChange() {
					syncEditorFromMetaBox( select.value );
				}
				select.addEventListener( 'change', onMetaBoxChange );
				teardown = function () { select.removeEventListener( 'change', onMetaBoxChange ); };
				return true;
			}
			if ( ! attachListener() ) {
				var t = setTimeout( attachListener, 500 );
				return function () { clearTimeout( t ); if ( teardown ) teardown(); };
			}
			return function () { if ( teardown ) teardown(); };
		}, [] );

		return wp.element.createElement( ResourceStatusPanel );
	}

	wp.domReady( function () {
		if ( ! wp.plugins || ! wp.editor || ! wp.data || ! wp.element ) {
			return;
		}
		wp.plugins.registerPlugin( 'erm-resource-status', {
			render: ERMBlockEditorPlugin
		} );
	} );
} )();
