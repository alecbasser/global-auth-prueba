<?php
/**
 * Single resource - inject styled meta into theme content.
 * Respeta el header y footer del tema.
 *
 * @package Education_Resources_Manager
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class ERM_Single_Template
 */
class ERM_Single_Template {

	/**
	 * Initialize.
	 */
	public function init() {
		add_filter( 'the_content', array( $this, 'add_resource_meta' ), 10, 1 );
		add_filter( 'body_class', array( $this, 'body_class' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		add_action( 'wp_head', array( $this, 'theme_script' ), 1 );
	}

	/**
	 * Inline script to prevent flash of wrong theme.
	 */
	public function theme_script() {
		if ( ! is_singular( ERM_Post_Type::POST_TYPE ) ) {
			return;
		}
		?>
		<script>
		(function(){
			var s=localStorage.getItem('erm-theme');
			var d=window.matchMedia('(prefers-color-scheme: dark)').matches;
			if(s==='dark'||(!s&&d)){document.documentElement.classList.add('dark');}
		})();
		</script>
		<?php
	}

	/**
	 * Add body class for single resource.
	 *
	 * @param array $classes Body classes.
	 * @return array
	 */
	public function body_class( $classes ) {
		if ( is_singular( ERM_Post_Type::POST_TYPE ) ) {
			$classes[] = 'erm-single-page';
		}
		return $classes;
	}

	/**
	 * Add resource meta to content (badges, author, CTA).
	 *
	 * @param string $content Post content.
	 * @return string
	 */
	public function add_resource_meta( $content ) {
		if ( ! is_singular( ERM_Post_Type::POST_TYPE ) || ! in_the_loop() || ! is_main_query() ) {
			return $content;
		}

		$post_id = get_the_ID();
		$meta    = ERM_Post_Type::get_resource_meta( $post_id );

		$type_labels = array(
			'course'   => __( 'Curso', 'education-resources-manager' ),
			'tutorial' => __( 'Tutorial', 'education-resources-manager' ),
			'ebook'    => __( 'Ebook', 'education-resources-manager' ),
			'video'    => __( 'Video', 'education-resources-manager' ),
		);

		$level_labels = array(
			'beginner'     => __( 'Principiante', 'education-resources-manager' ),
			'intermediate' => __( 'Intermedio', 'education-resources-manager' ),
			'advanced'     => __( 'Avanzado', 'education-resources-manager' ),
		);

		ob_start();
		?>
		<div class="erm-single erm-single-resource">
			<div class="erm-single__meta-block">
				<div class="erm-single__badges">
					<?php if ( ! empty( $meta['type'] ) ) : ?>
						<span class="erm-badge erm-badge--primary"><?php echo esc_html( $type_labels[ $meta['type'] ] ?? $meta['type'] ); ?></span>
					<?php endif; ?>
					<?php if ( ! empty( $meta['level'] ) ) : ?>
						<span class="erm-badge erm-badge--neutral"><?php echo esc_html( $level_labels[ $meta['level'] ] ?? $meta['level'] ); ?></span>
					<?php endif; ?>
					<?php if ( ! empty( $meta['duration'] ) && $meta['duration'] > 0 ) : ?>
						<span class="erm-badge erm-badge--neutral erm-badge--with-icon">
							<span class="erm-badge-icon" aria-hidden="true">⏱</span>
							<?php echo esc_html( sprintf( __( '%d min', 'education-resources-manager' ), $meta['duration'] ) ); ?>
						</span>
					<?php endif; ?>
				</div>

				<div class="erm-single__author-row">
					<?php if ( ! empty( $meta['instructor'] ) ) : ?>
						<div class="erm-single__author">
							<div class="erm-single__avatar"><?php echo esc_html( mb_substr( $meta['instructor'], 0, 1 ) ); ?></div>
							<div>
								<p class="erm-single__author-label"><?php esc_html_e( 'Escrito por', 'education-resources-manager' ); ?></p>
								<p class="erm-single__author-name"><?php echo esc_html( $meta['instructor'] ); ?></p>
							</div>
						</div>
					<?php endif; ?>
					<?php if ( ! empty( $meta['price'] ) ) : ?>
						<div class="erm-single__price">
							<p class="erm-single__price-label"><?php esc_html_e( 'Precio', 'education-resources-manager' ); ?></p>
							<p class="erm-single__price-value">
								<?php
								$price_display = ( strtolower( $meta['price'] ) === 'gratuito' || $meta['price'] === '0' )
									? __( 'Gratuito', 'education-resources-manager' )
									: esc_html( $meta['price'] );
								echo $price_display;
								?>
							</p>
						</div>
					<?php endif; ?>
				</div>
			</div>

			<?php if ( ! empty( $meta['url'] ) ) : ?>
				<div class="erm-single__cta">
					<a href="<?php echo esc_url( $meta['url'] ); ?>" class="erm-single__btn" target="_blank" rel="noopener">
						<span class="erm-btn-icon" aria-hidden="true">▶</span>
						<?php esc_html_e( 'Ver recurso', 'education-resources-manager' ); ?>
					</a>
				</div>
			<?php endif; ?>

			<div class="erm-single__body">
				<?php if ( ! empty( $content ) ) : ?>
					<h2 class="erm-single__section-title"><?php esc_html_e( 'Sinopsis del recurso', 'education-resources-manager' ); ?></h2>
				<?php endif; ?>
				<div class="erm-single__prose"><?php echo $content; ?></div>
			</div>

			<nav class="erm-single__bottom-nav" aria-label="<?php esc_attr_e( 'Navegación', 'education-resources-manager' ); ?>">
				<button type="button" class="erm-nav-item erm-nav-item--active" data-tab="read">
					<span class="erm-nav-icon" aria-hidden="true">📖</span>
					<span><?php esc_html_e( 'Leer', 'education-resources-manager' ); ?></span>
				</button>
				<button type="button" class="erm-nav-item" data-tab="audio">
					<span class="erm-nav-icon" aria-hidden="true">🎧</span>
					<span><?php esc_html_e( 'Audio', 'education-resources-manager' ); ?></span>
				</button>
				<button type="button" class="erm-nav-item" data-tab="notes">
					<span class="erm-nav-icon" aria-hidden="true">💬</span>
					<span><?php esc_html_e( 'Notas', 'education-resources-manager' ); ?></span>
				</button>
				<button type="button" class="erm-nav-item" data-tab="settings">
					<span class="erm-nav-icon" aria-hidden="true">⚙</span>
					<span><?php esc_html_e( 'Ajustes', 'education-resources-manager' ); ?></span>
				</button>
			</nav>

			<button type="button" class="erm-single__theme-toggle" id="erm-theme-toggle" aria-label="<?php esc_attr_e( 'Cambiar tema', 'education-resources-manager' ); ?>">
				<span class="erm-theme-icon erm-theme-icon--dark" aria-hidden="true">🌙</span>
				<span class="erm-theme-icon erm-theme-icon--light" aria-hidden="true">☀</span>
			</button>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Enqueue styles and scripts for single resource page.
	 */
	public function enqueue_assets() {
		if ( ! is_singular( ERM_Post_Type::POST_TYPE ) ) {
			return;
		}

		wp_enqueue_style(
			'erm-single',
			ERM_URL . 'public/css/erm-single.css',
			array(),
			ERM_VERSION
		);

		wp_enqueue_style(
			'erm-fonts',
			'https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap',
			array(),
			null
		);

		wp_enqueue_script(
			'erm-single',
			ERM_URL . 'public/js/erm-single.js',
			array(),
			ERM_VERSION,
			true
		);
	}
}
