/**
 * Block editor customization for erm_resource: replace default status panel
 * with a simplified panel showing only draft, published, archived.
 *
 * @package Education_Resources_Manager
 */
( function () {
	'use strict';

	function getPostType() {
		var post = wp.data.select( 'core/editor' ).getCurrentPost();
		return post ? post.type : '';
	}

	function getPostId() {
		var post = wp.data.select( 'core/editor' ).getCurrentPost();
		return post ? post.id : 0;
	}

	function getCurrentStatus() {
		var post = wp.data.select( 'core/editor' ).getCurrentPost();
		if ( ! post ) return 'publish';
		var s = post.status || 'publish';
		// Solo permitimos draft, publish, archived para recursos.
		if ( s === 'draft' || s === 'publish' || s === 'archived' ) return s;
		return 'publish';
	}

	function ResourceStatusPanel() {
		var postType = getPostType();
		if ( postType !== 'erm_resource' ) {
			return null;
		}

		var status = getCurrentStatus();
		var postId = getPostId();
		var postTypeSlug = getPostType();

		var __ = ( wp.i18n && wp.i18n.__ ) ? wp.i18n.__ : function( s ) { return s; };
		var statusMap = [
			{ value: 'draft', label: __( 'Borrador', 'education-resources-manager' ), description: __( 'No listo para publicar.', 'education-resources-manager' ) },
			{ value: 'publish', label: __( 'Publicado', 'education-resources-manager' ), description: __( 'Visible por todos.', 'education-resources-manager' ) },
			{ value: 'archived', label: __( 'Archivado', 'education-resources-manager' ), description: __( 'Recurso archivado, no visible.', 'education-resources-manager' ) }
		];

		function onChange( newStatus ) {
			wp.data.dispatch( 'core' ).editEntityRecord( 'postType', postTypeSlug, postId, { post_status: newStatus } );
		}

		return wp.element.createElement(
			wp.editor.PluginDocumentSettingPanel,
			{
				name: 'erm-resource-status',
				title: __( 'Estado y visibilidad', 'education-resources-manager' ),
				className: 'erm-resource-status-panel'
			},
			wp.element.createElement(
				'fieldset',
				{ className: 'components-radio-control' },
				wp.element.createElement(
					'legend',
					{ className: 'components-visually-hidden' },
					__( 'Estado', 'education-resources-manager' )
				),
				wp.element.createElement(
					'div',
					{ className: 'components-radio-control__group-wrapper' },
					statusMap.map( function ( opt ) {
						return wp.element.createElement(
							'div',
							{ key: opt.value, className: 'components-radio-control__option' },
							wp.element.createElement( 'input', {
								id: 'erm-status-' + opt.value,
								className: 'components-radio-control__input',
								type: 'radio',
								name: 'erm_resource_status',
								value: opt.value,
								checked: status === opt.value,
								onChange: function () { onChange( opt.value ); }
							} ),
							wp.element.createElement(
								'label',
								{ className: 'components-radio-control__label', htmlFor: 'erm-status-' + opt.value },
								opt.label
							),
							wp.element.createElement(
								'p',
								{ className: 'components-radio-control__option-description' },
								opt.description
							)
						);
					} )
				)
			)
		);
	}

	function ERMBlockEditorPlugin() {
		var postType = getPostType();
		if ( postType !== 'erm_resource' ) {
			return null;
		}

		// Remove default post-status panel for resources (password, scheduled, etc.).
		wp.element.useEffect( function () {
			var dispatch = wp.data.dispatch( 'core/edit-post' ) || wp.data.dispatch( 'core/editor' );
			if ( dispatch && typeof dispatch.removeEditorPanel === 'function' ) {
				dispatch.removeEditorPanel( 'post-status' );
			}
		}, [] );

		return wp.element.createElement( ResourceStatusPanel );
	}

	wp.domReady( function () {
		if ( ! wp.plugins || ! wp.editor || ! wp.data || ! wp.element ) {
			return;
		}
		wp.plugins.registerPlugin( 'erm-resource-status', {
			render: ERMBlockEditorPlugin
		} );
	} );
} )();
