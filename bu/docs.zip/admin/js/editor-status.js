/**
 * Block editor: add "Archivado" as radio option in native "Estado y visibilidad" panel.
 * Injects the option into the existing RadioControl for erm_resource.
 *
 * @package Education_Resources_Manager
 */

(function () {
	'use strict';

	const POST_TYPE = 'erm_resource';
	const ARCHIVED_ID = 'erm-status-archived';
	const ARCHIVED_VALUE = 'archived';
	const HANDLER_ATTR = 'data-erm-status-handler';
	const LOG_PREFIX = '[ERM Status]';

	function log() {
		if (typeof console !== 'undefined' && console.log) {
			console.log.apply(console, [LOG_PREFIX].concat(Array.prototype.slice.call(arguments)));
		}
	}

	function attachStatusChangeHandler(container, editPost) {
		if (container.hasAttribute(HANDLER_ATTR)) {
			log('attachStatusChangeHandler: ya tiene handler, skip');
			return;
		}
		container.setAttribute(HANDLER_ATTR, '1');
		log('attachStatusChangeHandler: listener agregado al container', container.className);
		container.addEventListener('click', function (e) {
			var el = e.target;
			var input = (el.type === 'radio') ? el : (el.htmlFor ? document.getElementById(el.htmlFor) : null);
			if (input && input.type === 'radio') {
				log('click en radio:', input.id || input.name, 'value=', input.value, 'checked=', input.checked);
			}
		}, true);
		container.addEventListener('change', function (e) {
			var input = e.target;
			log('change event:', {
				tagName: input.tagName,
				type: input.type,
				id: input.id,
				name: input.name,
				value: input.value,
				checked: input.checked,
				label: (input.labels && input.labels[0]) ? input.labels[0].textContent : 'n/a'
			});
			if (input.type !== 'radio') {
				log('change: ignorado, no es radio');
				return;
			}
			if (!input.checked) {
				log('change: ignorado, no checked');
				return;
			}
			var status = input.value;
			if (!status) {
				log('change: ignorado, value vacío');
				return;
			}
			var editorSelect = wp.data.select('core/editor');
			var statusAntes = editorSelect ? editorSelect.getEditedPostAttribute('status') : 'n/a';
			log('editPost llamando con status:', status, '| status antes:', statusAntes);
			try {
				editPost({ status: status });
				var statusDespues = editorSelect ? editorSelect.getEditedPostAttribute('status') : 'n/a';
				log('editPost OK | status después:', statusDespues);
			} catch (err) {
				log('editPost ERROR:', err.message, err);
			}
		});
	}

	function addArchivedOption() {
		var editorSelect = wp.data.select('core/editor');
		if (!editorSelect || editorSelect.getCurrentPostType() !== POST_TYPE) return;

		var existing = document.getElementById(ARCHIVED_ID);
		if (existing) return;

		// Opciones dentro de fieldset.editor-change-status__options > div.components-radio-control__group-wrapper
		var container = document.querySelector('.editor-change-status__options .components-radio-control__group-wrapper') ||
			document.querySelector('.editor-change-status__options');
		if (!container) {
			var firstOption = document.querySelector('.components-radio-control__option');
			container = firstOption && firstOption.parentElement;
		}
		if (!container) {
			log('addArchivedOption: no se encontró container');
			return;
		}
		var radios = container.querySelectorAll('input[type="radio"]');
		log('addArchivedOption: container encontrado', container.className, '| radios:', radios.length, Array.prototype.map.call(radios, function (r) { return r.value + '(' + (r.id || r.name) + ')'; }));

		var i18n = window.ermEditorStatus || {};
		var label = i18n.archived || 'Archivado';
		var desc = i18n.archivedDesc || 'No visible en el listado público.';

		var status = editorSelect.getEditedPostAttribute('status');
		var editorDispatch = wp.data.dispatch('core/editor');
		var editPost = editorDispatch.editPost;
		log('addArchivedOption: editPost existe?', typeof editPost, '| status actual:', status);
		if (typeof editPost !== 'function') {
			log('addArchivedOption: ERROR editPost no es función, dispatch keys:', Object.keys(editorDispatch || {}));
		}

		var option = document.createElement('div');
		option.className = 'components-radio-control__option';
		option.id = ARCHIVED_ID + '-wrapper';

		var input = document.createElement('input');
		input.id = ARCHIVED_ID;
		input.className = 'components-radio-control__input';
		input.type = 'radio';
		var firstInput = container.querySelector('.components-radio-control__input');
		input.name = (firstInput && firstInput.name) || 'inspector-radio-control-0';
		input.value = ARCHIVED_VALUE;
		input.setAttribute('aria-describedby', ARCHIVED_ID + '-desc');
		if (status === ARCHIVED_VALUE) input.checked = true;

		var labelEl = document.createElement('label');
		labelEl.className = 'components-radio-control__label';
		labelEl.htmlFor = ARCHIVED_ID;
		labelEl.textContent = label;

		var descEl = document.createElement('p');
		descEl.id = ARCHIVED_ID + '-desc';
		descEl.className = 'components-radio-control__option-description';
		descEl.textContent = desc;

		option.appendChild(input);
		option.appendChild(labelEl);
		option.appendChild(descEl);

		container.appendChild(option);
		attachStatusChangeHandler(container, editPost);
	}

	function updateArchivedChecked() {
		var editorSelect = wp.data.select('core/editor');
		if (!editorSelect || editorSelect.getCurrentPostType() !== POST_TYPE) return;

		var input = document.getElementById(ARCHIVED_ID);
		if (!input) return;

		var status = editorSelect.getEditedPostAttribute('status');
		var wasChecked = input.checked;
		input.checked = status === ARCHIVED_VALUE;
		if (wasChecked !== input.checked) {
			log('updateArchivedChecked: status=', status, 'archived checked=', input.checked);
		}
	}

	function init() {
		var editorSelect = wp.data.select('core/editor');
		if (!editorSelect || !editorSelect.getCurrentPostType) return;
		if (editorSelect.getCurrentPostType() !== POST_TYPE) return;

		log('init: plugin ERM cargado para', POST_TYPE);
		wp.data.subscribe(function () {
			updateArchivedChecked();
		});

		// Watch for status popover to appear (opens when user clicks Estado)
		var observer = new MutationObserver(function () {
			addArchivedOption();
			updateArchivedChecked();
		});
		observer.observe(document.body, { childList: true, subtree: true });

		// Also try when user might click - observe editor sidebar
		addArchivedOption();
	}

	function ERMStatusInfo() {
		var i18n = window.ermEditorStatus || {};
		var editorSelect = wp.data.select('core/editor');
		if (!editorSelect || !editorSelect.getCurrentPostType) return null;
		if (editorSelect.getCurrentPostType() !== POST_TYPE) return null;
		if (editorSelect.getEditedPostAttribute('status') !== ARCHIVED_VALUE) return null;

		return wp.element.createElement(
			wp.editor.PluginPostStatusInfo,
			{},
			wp.element.createElement('span', {}, (i18n.status || 'Estado') + ': ' + (i18n.archived || 'Archivado'))
		);
	}

	wp.domReady(function () {
		wp.plugins.registerPlugin('erm-post-status', {
			render: function () {
				init();
				return wp.element.createElement(ERMStatusInfo);
			},
		});
	});
})();
