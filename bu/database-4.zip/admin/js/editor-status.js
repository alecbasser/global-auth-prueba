/**
 * Block editor: add "Archivado" as radio option in native "Estado y visibilidad" panel.
 * Injects the option into the existing RadioControl for erm_resource.
 * Patches the status toggle button to show icon + label when status is "archived"
 * (WordPress core postStatusesInfo does not include custom statuses).
 *
 * @package Education_Resources_Manager
 */

(function () {
	'use strict';

	const POST_TYPE = 'erm_resource';
	const ARCHIVED_ID = 'erm-status-archived';
	const ARCHIVED_VALUE = 'archived';

	// SVG path for archive icon (from @wordpress/icons archive)
	const ARCHIVE_ICON_SVG = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" aria-hidden="true" focusable="false"><path fill-rule="evenodd" clip-rule="evenodd" d="M11.934 7.406a1 1 0 0 0 .914.594H19a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5H5a.5.5 0 0 1-.5-.5V6a.5.5 0 0 1 .5-.5h5.764a.5.5 0 0 1 .447.276l.723 1.63Zm1.064-1.216a.5.5 0 0 0 .462.31H19a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h5.764a2 2 0 0 1 1.789 1.106l.445 1.084ZM8.5 10.5h7V12h-7v-1.5Zm7 3.5h-7v1.5h7V14Z"></path></svg>';

	function patchArchivedToggleButton() {
		var editorSelect = wp.data.select('core/editor');
		if (!editorSelect || editorSelect.getCurrentPostType() !== POST_TYPE) return;

		var status = editorSelect.getEditedPostAttribute('status');
		if (status !== ARCHIVED_VALUE) return;

		var toggle = document.querySelector('.editor-post-status__toggle');
		if (!toggle) return;

		var label = (window.ermEditorStatus && window.ermEditorStatus.archived) || 'Archivado';

		// Only patch if button is empty (WordPress has no postStatusesInfo for archived)
		var hasText = toggle.textContent && toggle.textContent.trim().length > 0;
		var hasIcon = toggle.querySelector('svg');
		if (hasText && hasIcon) return;

		// Clear and set icon + text to match native status buttons (has-text has-icon)
		toggle.innerHTML = ARCHIVE_ICON_SVG + label;
		toggle.classList.add('has-text', 'has-icon');
		toggle.setAttribute('aria-label', 'Cambiar estado: ' + label);
	}

	function attachArchivedChangeHandler(input, postId) {
		input.addEventListener('change', function () {
			if (!input.checked) return;
			var editEntityRecord = wp.data.dispatch('core').editEntityRecord;
			var editPost = wp.data.dispatch('core/editor').editPost;
			if (typeof editEntityRecord === 'function') {
				editEntityRecord('postType', POST_TYPE, postId, { status: ARCHIVED_VALUE });
			}
			if (typeof editPost === 'function') {
				editPost({ status: ARCHIVED_VALUE });
			}
		});
	}

	function addArchivedOption() {
		var editorSelect = wp.data.select('core/editor');
		if (!editorSelect || editorSelect.getCurrentPostType() !== POST_TYPE) return;

		var existing = document.getElementById(ARCHIVED_ID);
		if (existing) return;

		// Opciones dentro de fieldset.editor-change-status__options > div.components-radio-control__group-wrapper
		var container = document.querySelector('.editor-change-status__options .components-radio-control__group-wrapper') ||
			document.querySelector('.editor-change-status__options');
		if (!container) {
			var firstOption = document.querySelector('.components-radio-control__option');
			container = firstOption && firstOption.parentElement;
		}
		if (!container) return;

		var i18n = window.ermEditorStatus || {};
		var label = i18n.archived || 'Archivado';
		var desc = i18n.archivedDesc || 'No visible en el listado público.';

		var status = editorSelect.getEditedPostAttribute('status');
		var postId = editorSelect.getCurrentPostId();
		if (!postId) return;

		var option = document.createElement('div');
		option.className = 'components-radio-control__option';
		option.id = ARCHIVED_ID + '-wrapper';

		var input = document.createElement('input');
		input.id = ARCHIVED_ID;
		input.className = 'components-radio-control__input';
		input.type = 'radio';
		var firstInput = container.querySelector('.components-radio-control__input');
		input.name = (firstInput && firstInput.name) || 'inspector-radio-control-0';
		input.value = ARCHIVED_VALUE;
		input.setAttribute('aria-describedby', ARCHIVED_ID + '-desc');
		if (status === ARCHIVED_VALUE) input.checked = true;

		var labelEl = document.createElement('label');
		labelEl.className = 'components-radio-control__label';
		labelEl.htmlFor = ARCHIVED_ID;
		labelEl.textContent = label;

		var descEl = document.createElement('p');
		descEl.id = ARCHIVED_ID + '-desc';
		descEl.className = 'components-radio-control__option-description';
		descEl.textContent = desc;

		option.appendChild(input);
		option.appendChild(labelEl);
		option.appendChild(descEl);

		container.appendChild(option);
		attachArchivedChangeHandler(input, postId);
	}

	function updateArchivedChecked() {
		var editorSelect = wp.data.select('core/editor');
		if (!editorSelect || editorSelect.getCurrentPostType() !== POST_TYPE) return;

		var input = document.getElementById(ARCHIVED_ID);
		if (!input) return;

		var status = editorSelect.getEditedPostAttribute('status');
		input.checked = status === ARCHIVED_VALUE;
	}

	function init() {
		var editorSelect = wp.data.select('core/editor');
		if (!editorSelect || !editorSelect.getCurrentPostType) return;
		if (editorSelect.getCurrentPostType() !== POST_TYPE) return;

		wp.data.subscribe(function () {
			updateArchivedChecked();
			// Patch toggle button after React re-render (status may have changed)
			setTimeout(patchArchivedToggleButton, 0);
		});

		// Watch for status popover to appear (opens when user clicks Estado)
		var observer = new MutationObserver(function () {
			addArchivedOption();
			updateArchivedChecked();
			patchArchivedToggleButton();
		});
		observer.observe(document.body, { childList: true, subtree: true });

		// Also try when user might click - observe editor sidebar
		addArchivedOption();
		// Patch toggle on init (e.g. when opening a post already archived)
		setTimeout(patchArchivedToggleButton, 100);
	}

	function ERMStatusInfo() {
		var i18n = window.ermEditorStatus || {};
		var editorSelect = wp.data.select('core/editor');
		if (!editorSelect || !editorSelect.getCurrentPostType) return null;
		if (editorSelect.getCurrentPostType() !== POST_TYPE) return null;
		if (editorSelect.getEditedPostAttribute('status') !== ARCHIVED_VALUE) return null;

		return wp.element.createElement(
			wp.editor.PluginPostStatusInfo,
			{},
			wp.element.createElement('span', {}, (i18n.status || 'Estado') + ': ' + (i18n.archived || 'Archivado'))
		);
	}

	wp.domReady(function () {
		wp.plugins.registerPlugin('erm-post-status', {
			render: function () {
				init();
				return wp.element.createElement(ERMStatusInfo);
			},
		});
	});
})();
