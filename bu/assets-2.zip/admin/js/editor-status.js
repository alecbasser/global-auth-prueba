/**
 * Block editor: add "Archivado" as radio option in native "Estado y visibilidad" panel.
 * Injects the option into the existing RadioControl for erm_resource.
 *
 * @package Education_Resources_Manager
 */

(function () {
	'use strict';

	const POST_TYPE = 'erm_resource';
	const ARCHIVED_ID = 'erm-status-archived';
	const ARCHIVED_VALUE = 'archived';

	function attachArchivedChangeHandler(input, postId) {
		input.addEventListener('change', function () {
			if (!input.checked) return;
			var editEntityRecord = wp.data.dispatch('core').editEntityRecord;
			var editPost = wp.data.dispatch('core/editor').editPost;
			if (typeof editEntityRecord === 'function') {
				editEntityRecord('postType', POST_TYPE, postId, { status: ARCHIVED_VALUE });
			}
			if (typeof editPost === 'function') {
				editPost({ status: ARCHIVED_VALUE });
			}
		});
	}

	function addArchivedOption() {
		var editorSelect = wp.data.select('core/editor');
		if (!editorSelect || editorSelect.getCurrentPostType() !== POST_TYPE) return;

		var existing = document.getElementById(ARCHIVED_ID);
		if (existing) return;

		// Opciones dentro de fieldset.editor-change-status__options > div.components-radio-control__group-wrapper
		var container = document.querySelector('.editor-change-status__options .components-radio-control__group-wrapper') ||
			document.querySelector('.editor-change-status__options');
		if (!container) {
			var firstOption = document.querySelector('.components-radio-control__option');
			container = firstOption && firstOption.parentElement;
		}
		if (!container) return;

		var i18n = window.ermEditorStatus || {};
		var label = i18n.archived || 'Archivado';
		var desc = i18n.archivedDesc || 'No visible en el listado público.';

		var status = editorSelect.getEditedPostAttribute('status');
		var postId = editorSelect.getCurrentPostId();
		if (!postId) return;

		var option = document.createElement('div');
		option.className = 'components-radio-control__option';
		option.id = ARCHIVED_ID + '-wrapper';

		var input = document.createElement('input');
		input.id = ARCHIVED_ID;
		input.className = 'components-radio-control__input';
		input.type = 'radio';
		var firstInput = container.querySelector('.components-radio-control__input');
		input.name = (firstInput && firstInput.name) || 'inspector-radio-control-0';
		input.value = ARCHIVED_VALUE;
		input.setAttribute('aria-describedby', ARCHIVED_ID + '-desc');
		if (status === ARCHIVED_VALUE) input.checked = true;

		var labelEl = document.createElement('label');
		labelEl.className = 'components-radio-control__label';
		labelEl.htmlFor = ARCHIVED_ID;
		labelEl.textContent = label;

		var descEl = document.createElement('p');
		descEl.id = ARCHIVED_ID + '-desc';
		descEl.className = 'components-radio-control__option-description';
		descEl.textContent = desc;

		option.appendChild(input);
		option.appendChild(labelEl);
		option.appendChild(descEl);

		container.appendChild(option);
		attachArchivedChangeHandler(input, postId);
	}

	function updateArchivedChecked() {
		var editorSelect = wp.data.select('core/editor');
		if (!editorSelect || editorSelect.getCurrentPostType() !== POST_TYPE) return;

		var input = document.getElementById(ARCHIVED_ID);
		if (!input) return;

		var status = editorSelect.getEditedPostAttribute('status');
		input.checked = status === ARCHIVED_VALUE;
	}

	function init() {
		var editorSelect = wp.data.select('core/editor');
		if (!editorSelect || !editorSelect.getCurrentPostType) return;
		if (editorSelect.getCurrentPostType() !== POST_TYPE) return;

		wp.data.subscribe(function () {
			updateArchivedChecked();
		});

		// Watch for status popover to appear (opens when user clicks Estado)
		var observer = new MutationObserver(function () {
			addArchivedOption();
			updateArchivedChecked();
		});
		observer.observe(document.body, { childList: true, subtree: true });

		// Also try when user might click - observe editor sidebar
		addArchivedOption();
	}

	function ERMStatusInfo() {
		var i18n = window.ermEditorStatus || {};
		var editorSelect = wp.data.select('core/editor');
		if (!editorSelect || !editorSelect.getCurrentPostType) return null;
		if (editorSelect.getCurrentPostType() !== POST_TYPE) return null;
		if (editorSelect.getEditedPostAttribute('status') !== ARCHIVED_VALUE) return null;

		return wp.element.createElement(
			wp.editor.PluginPostStatusInfo,
			{},
			wp.element.createElement('span', {}, (i18n.status || 'Estado') + ': ' + (i18n.archived || 'Archivado'))
		);
	}

	wp.domReady(function () {
		wp.plugins.registerPlugin('erm-post-status', {
			render: function () {
				init();
				return wp.element.createElement(ERMStatusInfo);
			},
		});
	});
})();
