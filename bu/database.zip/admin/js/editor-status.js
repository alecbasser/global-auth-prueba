/**
 * Block editor: add "Archivado" to status panel for erm_resource.
 *
 * @package Education_Resources_Manager
 */

(function () {
	'use strict';

	const POST_TYPE = 'erm_resource';

	function getStatusOptions(i18n) {
		return [
			{ value: 'draft', label: i18n.draft, description: i18n.draftDesc },
			{ value: 'publish', label: i18n.published, description: i18n.publishedDesc },
			{ value: 'archived', label: i18n.archived, description: i18n.archivedDesc },
		];
	}

	function getStatusLabel(status, i18n) {
		var labels = { draft: i18n.draft, publish: i18n.published, archived: i18n.archived, 'auto-draft': i18n.draft };
		return (i18n && labels[status]) || status;
	}

	function ERMStatusPanel() {
		var i18n = window.ermEditorStatus || {};
		var postType = wp.data.select('core/editor').getCurrentPostType();
		if (postType !== POST_TYPE) {
			return null;
		}

		var status = wp.data.select('core/editor').getEditedPostAttribute('status');
		var postId = wp.data.select('core/editor').getCurrentPostId();
		var editEntityRecord = wp.data.dispatch('core').editEntityRecord;

		var handleChange = function (value) {
			editEntityRecord('postType', POST_TYPE, postId, { status: value });
		};

		var options = getStatusOptions(i18n);
		var displayStatus = status === 'auto-draft' ? 'draft' : status;

		return wp.element.createElement(
			wp.editPost.PluginDocumentSettingPanel,
			{
				name: 'erm-status',
				title: i18n.status || 'Estado',
				className: 'erm-status-panel',
			},
			wp.element.createElement(
				wp.components.RadioControl,
				{
					label: i18n.status || 'Estado',
					options: options,
					selected: displayStatus,
					onChange: handleChange,
				}
			)
		);
	}

	function ERMStatusInfo() {
		var i18n = window.ermEditorStatus || {};
		var editorSelect = wp.data.select('core/editor');
		if (!editorSelect || !editorSelect.getCurrentPostType) return null;
		var postType = editorSelect.getCurrentPostType();
		if (postType !== POST_TYPE) return null;
		var status = editorSelect.getEditedPostAttribute('status');
		var label = getStatusLabel(status === 'auto-draft' ? 'draft' : status, i18n);
		return wp.element.createElement(
			wp.editor.PluginPostStatusInfo,
			{},
			wp.element.createElement('span', {}, (i18n.status || 'Estado') + ': ' + label)
		);
	}

	wp.domReady(function () {
		var panelRemoved = false;
		wp.data.subscribe(function () {
			if (panelRemoved) return;
			var editorSelect = wp.data.select('core/editor');
			var postType = editorSelect && editorSelect.getCurrentPostType ? editorSelect.getCurrentPostType() : null;
			if (postType === POST_TYPE) {
				var editPostDispatch = wp.data.dispatch('core/edit-post');
				if (editPostDispatch && editPostDispatch.removeEditorPanel) {
					editPostDispatch.removeEditorPanel('post-status');
				}
				panelRemoved = true;
			}
		});

		wp.plugins.registerPlugin('erm-post-status', {
			render: function () {
				return wp.element.createElement(
					wp.element.Fragment,
					{},
					wp.element.createElement(ERMStatusPanel),
					wp.element.createElement(ERMStatusInfo)
				);
			},
		});
	});
})();
