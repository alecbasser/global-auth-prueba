/**
 * Block editor: add "Archivado" option to status panel for erm_resource.
 * Keeps default status options (Draft, Pending, Private, Scheduled, Published) and adds Archivado.
 *
 * @package Education_Resources_Manager
 */

(function () {
	'use strict';

	const POST_TYPE = 'erm_resource';

	function ERMArchivedOption() {
		var i18n = window.ermEditorStatus || {};
		var editorSelect = wp.data.select('core/editor');
		if (!editorSelect || !editorSelect.getCurrentPostType) return null;
		var postType = editorSelect.getCurrentPostType();
		if (postType !== POST_TYPE) return null;

		var status = editorSelect.getEditedPostAttribute('status');
		var postId = editorSelect.getCurrentPostId();
		var editEntityRecord = wp.data.dispatch('core').editEntityRecord;

		var isArchived = status === 'archived';

		var handleChange = function (checked) {
			editEntityRecord('postType', POST_TYPE, postId, {
				status: checked ? 'archived' : 'publish',
			});
		};

		return wp.element.createElement(
			wp.editPost.PluginDocumentSettingPanel,
			{
				name: 'erm-archived',
				title: i18n.archived || 'Archivado',
				className: 'erm-archived-panel',
			},
			wp.element.createElement(
				wp.components.CheckboxControl,
				{
					label: i18n.archivedDesc || 'No visible en el listado público.',
					help: i18n.archivedHelp || 'Marca para archivar este recurso.',
					checked: isArchived,
					onChange: handleChange,
				}
			)
		);
	}

	function ERMStatusInfo() {
		var i18n = window.ermEditorStatus || {};
		var editorSelect = wp.data.select('core/editor');
		if (!editorSelect || !editorSelect.getCurrentPostType) return null;
		var postType = editorSelect.getCurrentPostType();
		if (postType !== POST_TYPE) return null;

		var status = editorSelect.getEditedPostAttribute('status');
		if (status !== 'archived') return null;

		return wp.element.createElement(
			wp.editor.PluginPostStatusInfo,
			{},
			wp.element.createElement('span', {}, (i18n.status || 'Estado') + ': ' + (i18n.archived || 'Archivado'))
		);
	}

	wp.domReady(function () {
		wp.plugins.registerPlugin('erm-post-status', {
			render: function () {
				return wp.element.createElement(
					wp.element.Fragment,
					{},
					wp.element.createElement(ERMArchivedOption),
					wp.element.createElement(ERMStatusInfo)
				);
			},
		});
	});
})();
