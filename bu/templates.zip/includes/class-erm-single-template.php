<?php
/**
 * Single resource template - custom layout with elegant design.
 *
 * @package Education_Resources_Manager
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class ERM_Single_Template
 */
class ERM_Single_Template {

	/**
	 * Initialize.
	 */
	public function init() {
		add_filter( 'template_include', array( $this, 'load_template' ), 99 );
		add_filter( 'body_class', array( $this, 'body_class' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		add_action( 'wp_head', array( $this, 'theme_script' ), 1 );
	}

	/**
	 * Inline script to prevent flash of wrong theme.
	 */
	public function theme_script() {
		if ( ! is_singular( ERM_Post_Type::POST_TYPE ) ) {
			return;
		}
		?>
		<script>
		(function(){
			var s=localStorage.getItem('erm-theme');
			var d=window.matchMedia('(prefers-color-scheme: dark)').matches;
			if(s==='dark'||(!s&&d)){document.documentElement.classList.add('dark');}
		})();
		</script>
		<?php
	}

	/**
	 * Add body class for single resource.
	 *
	 * @param array $classes Body classes.
	 * @return array
	 */
	public function body_class( $classes ) {
		if ( is_singular( ERM_Post_Type::POST_TYPE ) ) {
			$classes[] = 'erm-single-page';
		}
		return $classes;
	}

	/**
	 * Load custom template for single resource.
	 *
	 * @param string $template Template path.
	 * @return string
	 */
	public function load_template( $template ) {
		if ( is_singular( ERM_Post_Type::POST_TYPE ) ) {
			$custom = ERM_PATH . 'templates/single-erm_resource.php';
			if ( file_exists( $custom ) ) {
				return $custom;
			}
		}
		return $template;
	}

	/**
	 * Enqueue styles and scripts for single resource page.
	 */
	public function enqueue_assets() {
		if ( ! is_singular( ERM_Post_Type::POST_TYPE ) ) {
			return;
		}

		wp_enqueue_style(
			'erm-single',
			ERM_URL . 'public/css/erm-single.css',
			array(),
			ERM_VERSION
		);

		wp_enqueue_style(
			'erm-fonts',
			'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Playfair+Display:wght@700&family=Lora:ital,wght@0,400;0,500;1,400&display=swap',
			array(),
			null
		);

		wp_enqueue_script(
			'erm-single',
			ERM_URL . 'public/js/erm-single.js',
			array(),
			ERM_VERSION,
			true
		);
	}
}
