<?php
/**
 * Single resource template - custom layout.
 *
 * @package Education_Resources_Manager
 */

defined( 'ABSPATH' ) || exit;

get_header();

$type_labels = array(
	'course'   => __( 'Curso', 'education-resources-manager' ),
	'tutorial' => __( 'Tutorial', 'education-resources-manager' ),
	'ebook'    => __( 'Ebook', 'education-resources-manager' ),
	'video'    => __( 'Video', 'education-resources-manager' ),
);

$level_labels = array(
	'beginner'     => __( 'Principiante', 'education-resources-manager' ),
	'intermediate' => __( 'Intermedio', 'education-resources-manager' ),
	'advanced'     => __( 'Avanzado', 'education-resources-manager' ),
);

while ( have_posts() ) :
	the_post();
	$post_id = get_the_ID();
	$meta    = ERM_Post_Type::get_resource_meta( $post_id );
	$thumbnail = get_the_post_thumbnail_url( $post_id, 'large' );
	?>
	<main class="erm-single erm-single-resource" role="main">
		<header class="erm-single__header">
			<button type="button" class="erm-single__back" onclick="history.back()" aria-label="<?php esc_attr_e( 'Volver', 'education-resources-manager' ); ?>">
				<span class="erm-icon" aria-hidden="true">←</span>
			</button>
			<div class="erm-single__header-actions">
				<button type="button" class="erm-single__action" id="erm-share" aria-label="<?php esc_attr_e( 'Compartir', 'education-resources-manager' ); ?>">
					<span class="erm-icon" aria-hidden="true">⎘</span>
				</button>
				<button type="button" class="erm-single__action" id="erm-bookmark" aria-label="<?php esc_attr_e( 'Guardar', 'education-resources-manager' ); ?>">
					<span class="erm-icon erm-icon-bookmark" aria-hidden="true">☆</span>
				</button>
			</div>
		</header>

		<article class="erm-single__article">
			<div class="erm-single__hero">
				<?php if ( $thumbnail ) : ?>
					<div class="erm-single__image-wrap">
						<img src="<?php echo esc_url( $thumbnail ); ?>" alt="" class="erm-single__image" loading="eager" />
						<div class="erm-single__image-overlay"></div>
					</div>
				<?php endif; ?>
			</div>

			<div class="erm-single__content">
				<h1 class="erm-single__title"><?php the_title(); ?></h1>

				<div class="erm-single__badges">
					<?php if ( ! empty( $meta['type'] ) ) : ?>
						<span class="erm-badge erm-badge--primary"><?php echo esc_html( $type_labels[ $meta['type'] ] ?? $meta['type'] ); ?></span>
					<?php endif; ?>
					<?php if ( ! empty( $meta['level'] ) ) : ?>
						<span class="erm-badge erm-badge--neutral"><?php echo esc_html( $level_labels[ $meta['level'] ] ?? $meta['level'] ); ?></span>
					<?php endif; ?>
					<?php if ( ! empty( $meta['duration'] ) && $meta['duration'] > 0 ) : ?>
						<span class="erm-badge erm-badge--neutral erm-badge--with-icon">
							<span class="erm-badge-icon" aria-hidden="true">⏱</span>
							<?php echo esc_html( sprintf( __( '%d min', 'education-resources-manager' ), $meta['duration'] ) ); ?>
						</span>
					<?php endif; ?>
				</div>

				<div class="erm-single__author-row">
					<?php if ( ! empty( $meta['instructor'] ) ) : ?>
						<div class="erm-single__author">
							<div class="erm-single__avatar"><?php echo esc_html( mb_substr( $meta['instructor'], 0, 1 ) ); ?></div>
							<div>
								<p class="erm-single__author-label"><?php esc_html_e( 'Escrito por', 'education-resources-manager' ); ?></p>
								<p class="erm-single__author-name"><?php echo esc_html( $meta['instructor'] ); ?></p>
							</div>
						</div>
					<?php endif; ?>
					<?php if ( ! empty( $meta['price'] ) ) : ?>
						<div class="erm-single__price">
							<p class="erm-single__price-label"><?php esc_html_e( 'Precio', 'education-resources-manager' ); ?></p>
							<p class="erm-single__price-value">
								<?php
								$price_display = ( strtolower( $meta['price'] ) === 'gratuito' || $meta['price'] === '0' )
									? __( 'Gratuito', 'education-resources-manager' )
									: esc_html( $meta['price'] );
								echo $price_display;
								?>
							</p>
						</div>
					<?php endif; ?>
				</div>
			</div>

			<?php if ( ! empty( $meta['url'] ) ) : ?>
				<section class="erm-single__cta">
					<a href="<?php echo esc_url( $meta['url'] ); ?>" class="erm-single__btn" target="_blank" rel="noopener">
						<span class="erm-btn-icon" aria-hidden="true">▶</span>
						<?php esc_html_e( 'Ver recurso', 'education-resources-manager' ); ?>
					</a>
				</section>
			<?php endif; ?>

			<section class="erm-single__body">
				<h2 class="erm-single__section-title"><?php esc_html_e( 'Sinopsis del recurso', 'education-resources-manager' ); ?></h2>
				<div class="erm-single__prose">
					<?php the_content(); ?>
				</div>
			</section>
		</article>

		<nav class="erm-single__bottom-nav" aria-label="<?php esc_attr_e( 'Navegación', 'education-resources-manager' ); ?>">
			<button type="button" class="erm-nav-item erm-nav-item--active" data-tab="read">
				<span class="erm-nav-icon" aria-hidden="true">📖</span>
				<span><?php esc_html_e( 'Leer', 'education-resources-manager' ); ?></span>
			</button>
			<button type="button" class="erm-nav-item" data-tab="audio">
				<span class="erm-nav-icon" aria-hidden="true">🎧</span>
				<span><?php esc_html_e( 'Audio', 'education-resources-manager' ); ?></span>
			</button>
			<button type="button" class="erm-nav-item" data-tab="notes">
				<span class="erm-nav-icon" aria-hidden="true">💬</span>
				<span><?php esc_html_e( 'Notas', 'education-resources-manager' ); ?></span>
			</button>
			<button type="button" class="erm-nav-item" data-tab="settings">
				<span class="erm-nav-icon" aria-hidden="true">⚙</span>
				<span><?php esc_html_e( 'Ajustes', 'education-resources-manager' ); ?></span>
			</button>
		</nav>

		<button type="button" class="erm-single__theme-toggle" id="erm-theme-toggle" aria-label="<?php esc_attr_e( 'Cambiar tema', 'education-resources-manager' ); ?>">
			<span class="erm-theme-icon erm-theme-icon--dark" aria-hidden="true">🌙</span>
			<span class="erm-theme-icon erm-theme-icon--light" aria-hidden="true">☀</span>
		</button>
	</main>
	<?php
endwhile;

get_footer();
